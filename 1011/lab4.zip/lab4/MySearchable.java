public interface MySearchable {
	public void put(int item);
	public boolean exist(int item);
}